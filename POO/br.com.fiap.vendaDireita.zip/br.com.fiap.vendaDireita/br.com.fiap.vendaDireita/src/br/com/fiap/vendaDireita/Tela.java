package br.com.fiap.vendaDireita;

import java.util.Scanner;

public class Tela {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Criação da instância da consultora
		Consultora consultora = new Consultora();

		// Entrada de dados da consultora
		System.out.print("Digite o nome da consultor(a): ");
		consultora.nome = scanner.next();

		System.out.print("Digite o CPF da consultor(a) (apenas números): ");
		String cpfConsultor = scanner.next();
		
		// Entrada e formatação do CPF
		while (true) {
			// Verifica se o CPF tem 11 dígitos

			// O método matches é uma função da classe String em Java que verifica se a
			// string atual corresponde a um padrão definido por uma expressão regular
			// (regex).
			
			//regex: É uma string que representa a expressão regular que você deseja usar para comparar com a string atual.
			
			// \\d: Representa qualquer dígito (0-9).

			if (cpfConsultor.length() == 11 && cpfConsultor.matches("\\d{11}")) {
				// Formata o CPF
				consultora.cpf = formatarCPF(cpfConsultor);
				break; // CPF válido, sai do loop
			} else {
				System.out.println("CPF inválido. Tente novamente.");
				System.out.print("Digite o CPF da consultor(a) (apenas números): ");
				cpfConsultor = scanner.next();
			}
		}

		System.out.print("Digite o ID da consultor(a): ");
		consultora.id = scanner.nextInt();

		// Criação da instância do produto
		Produto produto = new Produto();

		// Entrada de dados do produto
		System.out.print("Digite o código do produto: ");
		produto.codigo = scanner.next();

		System.out.print("Digite o nome do produto: ");
		produto.nome = scanner.next();

		System.out.print("Digite o valor do produto: ");
		produto.preco = scanner.nextDouble();

		// Valor fixo que o produto está disponível
		produto.status = true;

		// Valor fixo do estoque do produto
		produto.estoque = 500;

		// Criação do pedido
		Pedido pedido = new Pedido(produto, consultora);

		// Exibição dos detalhes do pedido
		System.out.println();
		System.out.println(pedido);

		// Aplica o desconto fixo ao pedido
		pedido.aplicarDesconto();

		// Exibe os detalhes do pedido após aplicar o desconto
		System.out.println();
		System.out.println("Após aplicar o desconto:");
		System.out.println(pedido);

		// Fecha o scanner
		scanner.close();
	}

	public static String formatarCPF(String cpf) {
		// Formata o CPF para o padrão xxx.xxx.xxx-xx
		return String.format("%s.%s.%s-%s", cpf.substring(0, 3), cpf.substring(3, 6), cpf.substring(6, 9),
				cpf.substring(9, 11));
	}
}
