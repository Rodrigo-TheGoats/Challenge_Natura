package br.com.fiap.vendaDireita;

public class Pedido {
    protected Produto produto;
    protected Consultora consultora;

    public Pedido(Produto produto, Consultora consultora) {
        this.produto = produto;
        this.consultora = consultora;
    }

    @Override
    public String toString() {
        return "---------- Detalhes do pedido ----------\n" + consultora + "\n" + produto;
    }

    public void aplicarDesconto() {
        produto.aplicarDesconto();
    }
    
    public Pedido() {}
}