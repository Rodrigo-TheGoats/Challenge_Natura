package entidades;

public class Revendedor {
    private String produtos;
    private float avaliacao;
    private String nome;

    public Revendedor(String nome, String produtos, float avaliacao) {
        this.nome = nome;
        this.produtos = produtos;
        this.avaliacao = avaliacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProdutos() {
        return produtos;
    }

    public void setProdutos(String produtos) {
        this.produtos = produtos;
    }

    public float getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(float avaliacao) {
        this.avaliacao = avaliacao;
    }
}
