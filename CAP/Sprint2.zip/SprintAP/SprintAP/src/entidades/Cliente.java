package entidades;

public class Cliente {
    private String preferenciaCompra;
    private String historicoCompra;
    private String nome;

    public Cliente(String nome, String preferenciaCompra, String historicoCompra) {
        this.nome = nome;
        this.preferenciaCompra = preferenciaCompra;
        this.historicoCompra = historicoCompra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreferenciaCompra() {
        return preferenciaCompra;
    }

    public void setPreferenciaCompra(String preferenciaCompra) {
        this.preferenciaCompra = preferenciaCompra;
    }

    public String getHistoricoCompra() {
        return historicoCompra;
    }

    public void setHistoricoCompra(String historicoCompra) {
        this.historicoCompra = historicoCompra;
    }
}
