package teste;

import entidades.Cliente;
import entidades.Revendedor;
import listas.Fila;

public class ImplementaFila {
    public static void main(String[] args) {
    	Fila<Cliente> filaCliente = new Fila<>();
        Fila<Revendedor> filaRevendedor = new Fila<>();

        filaCliente.init();
        filaRevendedor.init();

//      INSERÇÂO DE CLIENTES
        Cliente cliente1 = new Cliente("Carlos", "Shampoo", "Condicionador");
        Cliente cliente2 = new Cliente("Pedro", "Condicionador", "Shampoo");
        Cliente cliente3 = new Cliente("Jose","Creme de pele", "Protetor solar");
        Cliente cliente4 = new Cliente("Bonifacio", "Shampoo", "Perfume");

        filaCliente.enqueue(cliente1);
        filaCliente.enqueue(cliente2);
        filaCliente.enqueue(cliente3);
        filaCliente.enqueue(cliente4);

//      INSERÇÂO DE REVENDEDORES
        Revendedor revendedor1 = new Revendedor("Thiago", "Shampoo", 3.1F);
        Revendedor revendedor2 = new Revendedor("Rodrigo", "Condicionador", 5);
        Revendedor revendedor3 = new Revendedor("Felipe", "Creme de pele", 5);
        Revendedor revendedor4 = new Revendedor("Samuel",  "Shampoo", 4.21F);

        filaRevendedor.enqueue(revendedor1);
        filaRevendedor.enqueue(revendedor2);
        filaRevendedor.enqueue(revendedor3);
        filaRevendedor.enqueue(revendedor4);

//      AMOSTRAGEM DOS DADOS
//      Clientes
        System.out.println("Fila após adicionar clientes:");
        for(int i = 0; i < filaCliente.getLen(); i++) {
            System.out.print(filaCliente.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();

        System.out.println("O nome do cliente de posicao 1 = " + filaCliente.buscaFila(1).getNome());

        System.out.println();

        filaCliente.dequeue();
        System.out.println("Lista de clientes apos primeiro dequeue:");
        for(int i = 0; i < filaCliente.getLen(); i++) {
            System.out.print(filaCliente.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();

        filaCliente.dequeue();
        System.out.println("Lista de clientes apos segundo dequeue:");
        for(int i = 0; i < filaCliente.getLen(); i++) {
            System.out.print(filaCliente.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();





//      Revendedores
        System.out.println("Fila apos adicionar Revendedores:");
        for(int i = 0; i < filaRevendedor.getLen(); i++) {
            System.out.print(filaRevendedor.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();

        System.out.println("O nome do revendedor de posicao 2 = " + filaRevendedor.buscaFila(2).getNome());

        System.out.println();

        filaRevendedor.dequeue();
        System.out.println("Lista de revendedores apos primeiro dequeue:");
        for(int i = 0; i < filaRevendedor.getLen(); i++) {
            System.out.print(filaRevendedor.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();

        filaRevendedor.dequeue();
        System.out.println("Lista de revendedores apos segundo dequeue:");
        for(int i = 0; i < filaRevendedor.getLen(); i++) {
            System.out.print(filaRevendedor.buscaFila(i).getNome() + " -> ");
        }
        System.out.println("Null");

        System.out.println();
    }
}