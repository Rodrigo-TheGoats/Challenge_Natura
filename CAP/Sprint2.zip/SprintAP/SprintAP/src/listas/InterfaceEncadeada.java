package listas;

public interface InterfaceEncadeada<T> {
    public T init();
    public T enqueue(T valor);
    public T isEmpty();
    public T dequeue();
    public T buscaFila(T valor);
    public T exibirFila();
}
