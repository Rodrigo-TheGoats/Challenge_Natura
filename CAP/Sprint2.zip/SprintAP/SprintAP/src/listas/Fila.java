package listas;

public class Fila <T> {
	No ini;
	No fim;
	private int len = 0;

	public T init() {
		ini = null;
		fim = null;
		return null;
	}


    class No {
    	T valor;
    	No prox;
    	
    	public No(T valor) {
    		this.valor = valor;
    		prox = null;
    	}

    }


    public void enqueue(T valor) {
        No novoNo = new No(valor);
        
        if (isEmpty()) {
            ini = novoNo;
            fim = novoNo;
        }
        
        fim.prox = novoNo;        	        
        fim = novoNo;
		len++;
    }
    
    public boolean isEmpty() {
    	if(ini == null && fim == null) {
    		return true;
    	}
    	return false;
    }

    public void dequeue() {
        if (isEmpty()) return;

        No temp = ini;
        ini = ini.prox;
		len--;
    }

    public T buscaFila(int valor) {
    	No temp = ini;
    	for(int i = 0; i < valor; i++) {
			temp = temp.prox;
		}
    	if(!isEmpty()) {
			return temp.valor;
		}
		return null;
    }

//	Exibe, porém com o endereco de memoria de cada objeto, verificar depois
    public void exibirFila() {
    	No inicio = ini;
    	
    	while(inicio != null) {
    		System.out.print(inicio.valor + " -> " );
    		inicio = inicio.prox;
    	}
		System.out.println(inicio);
    }

	public int getLen() {
		return len;
	}

}